## [1.5.3-text] - 2026-11-17
### Added
- Initial release of TextAnimator. TextMeshPro (Unity 2021.2+) and UI Toolkit (Unity 6.0006+, PanelRenderer) support.
- TextAnimator on the Asset Store: https://assetstore.unity.com/packages/slug/415774
- WebGL demo: https://kyrylokuzyk.github.io/PrimeTween/

## [1.5.3] - 2026-11-17
### Added
- Added `TweenAnimation` and `TweenAnimationComponent` to the free version with a limited set of tween types.

## [1.5.2] - 2026-10-28
### Added
- Unity 7 support.
- Added `Tween.___Additive` to animate delta changes instead of absolute values. This allows multiple additive tweens to animate the same value simultaneously, combining (blending) their changes.
- Added Sequence.OnUpdate callback that is invoked every time the sequence updates, after all its children animations are updated.
- Added `Tween/Sequence.OnFinally()` callback that is invoked when an animation is stopped for any reason (even if the target was destroyed). Use this callback as a "catch all" to run a clean-up.
- Added the `useDurationAsSpeed` parameter to `Tween.Custom()` and `Tween.CustomAdditive()` to create custom animations based on the speed instead of duration. [#182](https://github.com/KyryloKuzyk/PrimeTween/issues/182)
- Added a toggle near the 'Start Value' of `TweenSettings<T>` in the Inspector. Disable the toggle to start the animation from the current value (`startFromCurrent = true`). [#226](https://github.com/KyryloKuzyk/PrimeTween/issues/226)
- Experimental: added `Tween/Sequence.SetClock(Tween.Clock)` to control the timescale and tick of animations grouped together. Use `clock.timeScale` to set the timescale of all animations that share this clock. Use `clock.isManual` together with `clock.Tick(deltaTime)` to update the clock manually. Changes to the clock are applied on the next animation update. To fully control the update order, use `PrimeTweenConfig.ManualUpdate()`.
### Fixed
- Fixed: `Tween.Complete()` invoked OnComplete a second time on a tween that had completed while paused, for example, after `isPaused = true` and `progressTotal = 1`.

## [1.5.2-pro] - 2026-10-28
### Added
- Added `TweenAnimation.animationType`: Simple, Reversible, Infinite, or Overlapping. It replaces the `isReversible` setting, and `cycles = -1` for infinite animations. The change is backward compatible.
- Added additive animations support to TweenAnimation. https://github.com/KyryloKuzyk/PrimeTween/discussions/255 
- Added `AnimationType.Overlapping`: triggering a playing animation plays a new animation on top of it, while the previous one plays until its end. Use it with additive tweens to blend and accumulate their changes.
### Fixed
- Fixed: clicking TweenAnimation fields in the Inspector resets the animation in Play Mode. This is limited to the Edit Mode now.
- Fixed: TweenAnimationComponent with multiple targets restored all targets to the initial value of the first target after the Edit Mode preview.
- Fixed: a nested TweenAnimation with an even number of Yoyo or Rewind cycles jumped to its end values when its reversible parent started playing backward.
- Fixed: the `state` of a nested reversible `TweenAnimation` didn't match its targets after the parent was stopped after completion, moved to the end with `progressTotal = 1` while paused, interrupted with `InterruptionMode.Complete`, or completed in a backward cycle of an infinite Yoyo animation. Toggling the nested animation then snapped its targets to the start.
- Fixed: `TweenAnimation.Reset()` during the backward play of a reversible animation reset the animation to the end instead of the beginning.
- Fixed: `TweenAnimation` with an even number of Yoyo or Rewind cycles, or with Incremental cycles, didn't restore the initial values after the Edit Mode preview.

## [1.5.1] - 2026-10-21
### Added
- Added an optional `getCurrentValue` parameter to `Tween.Custom()` methods that accept `TweenSettings<T>`. It enables `startFromCurrent` support for Custom tweens.
- Added `Tween.Custom<T, TPayload>(target, payload, settings, onValueChange, getCurrentValue)` overloads that pass a struct payload to onValueChange and getCurrentValue without producing garbage. The payload can be any struct without reference type fields, up to 16 bytes.
### Changed
- The max payload size of `Tween.Delay<T, TPayload>()`, `Sequence.ChainCallback<T, TPayload>()`, and `Sequence.InsertCallback<T, TPayload>()` is reduced from 120 to 16 bytes to match `Tween.Custom<T, TPayload>()`.

## [1.5.1-pro] - 2026-10-21
### Added
- Added an optional `materialIndex` parameter to `Tween.MaterialPropertyBlock...()` methods to animate only one material of a Renderer with multiple materials. https://github.com/KyryloKuzyk/PrimeTween/discussions/256
### Fixed
- Fixed: destroying `TweenAnimationComponent` with `resetOnCompletion` logged an error that the tween's OnComplete callback was ignored. https://github.com/KyryloKuzyk/PrimeTween/issues/254
- Fixed: `Tween.MaterialPropertyBlockTextureScale()` overwrote the texture offset previously animated by `Tween.MaterialPropertyBlockTextureOffset()` with the material's value, and vice versa.
- Fixed: `Tween.MaterialPropertyBlockTextureScale/Offset()` with `startFromCurrent` ignored the current value in the MaterialPropertyBlock and started from the material's value.
- Fixed: `TweenAnimationComponent` with `MaterialPropertyBlockTextureScale/Offset` ignored the current value in the MaterialPropertyBlock and read the start value from the material in Edit Mode.

## [1.5.0] - 2026-10-10
### Added
- Added `Tween.Delay<T, TPayload>()`, `Sequence.ChainCallback<T, TPayload>()`, and `Sequence.InsertCallback<T, TPayload>()` overloads that pass a struct payload to the callback without producing garbage. The payload can be any struct without reference type fields, up to 120 bytes.
- Added `Sequence.ChainWaitWhile/Until()` and `Sequence.InsertWaitWhile/Until()` methods that suspend the sequence while (or until) a user-provided predicate returns true. 
- Added `Sequence.isWaiting` property that returns 'true' if the sequence is currently suspended by a wait.
- Added `cancellationMode` parameter to `SetCancellationToken()` and the global `PrimeTweenConfig.defaultCancellationMode` setting to control whether an animation is stopped or completed when its `CancellationToken` is canceled.
- All `PrimeTweenConfig.warn*` settings now have public getters, so it's possible to temporarily disable a warning and then restore its previous value.
### Fixed
- Fixed a number of rare edge cases found by extensive fuzz testing of the public API. They mostly involved calling PrimeTween API recursively from user-defined callbacks (OnComplete, OnUpdate, Tween.Custom) or using extreme durations. 
- Fixed: `Tween.CompleteAll()` froze the app when an `OnComplete()` callback restarted its own animation. `Tween.CompleteAll()` now completes only animations that are running when it's called.
- Fixed: endDelay in the PrimeTweenManager's inspector didn't show the correct value. Also, "cyclesDone" had an incorrect spelling in the PrimeTweenManager's inspector.

## [1.4.12] - 2026-07-24
### Fixed
- Fixed installation in Unity 6000.5.5.

## [1.4.10-pro] - 2026-07-18
### Added
- Added `SetCancellationToken(CancellationToken)` to `TweenAnimation`.
- TweenAnimationComponent and the owner of TweenAnimation now populate the 'unityTarget' in PrimeTweenManager's Inspector.
- UniTask integration.

## [1.4.10] - 2026-07-18
### Added
- Added `SetCancellationToken(CancellationToken)` to `Tween`, `Sequence`.
- UniTask integration.
- Added main thread check to all PrimeTween APIs.
### Fixed
- Fixed: compilation error when the project contains a plugin DLL that duplicates a framework type (e.g., a custom System.CodeDom.dll). PrimeTween's asmdefs now enable "Override References" to avoid the conflict. https://github.com/KyryloKuzyk/PrimeTween/issues/251
- Fixed: Unity 6000.7 shows a warning that the DEVELOPMENT_BUILD define is deprecated.
- Fixed: Unity 6000.7 shows a warning that `AppDomain.CurrentDomain.GetAssemblies()` is deprecated.

## [1.4.9-pro] - 2026-06-21
### Fixed
- Fixed: the project doesn't compile because ResetComponentsInEditor() is not wrapped with `#if UNITY_EDITOR`. https://github.com/KyryloKuzyk/PrimeTween/issues/250

## [1.4.8] - 2026-06-19
### Fixed
- Fixed: a rotation tween starting from an exactly 180° rotation (a quaternion with `w == 0`, e.g., `(0, 1, 0, 0)`) snapped to the end value instead of interpolating. https://github.com/KyryloKuzyk/PrimeTween/issues/247
- Fixed: the `warnEndValueEqualsCurrent` warning was not reported for rotation tweens when the `endValue` was the same rotation as the current value but expressed with the opposite quaternion sign (`-q`). Also, optimized the equality comparison order: https://github.com/KyryloKuzyk/PrimeTween/issues/229

## [1.4.8-pro] - 2026-06-17
### Added
- Added `Is Reversed` setting to TweenType.TweenAnimationComponent in the Inspector. This setting can be used to reverse the direction of a nested animation. https://github.com/KyryloKuzyk/PrimeTween/issues/243
### Fixed
- Fixed: PropertyDrawer fails to resolve TweenAnimation when it is stored in an inherited private serialized member. https://github.com/KyryloKuzyk/PrimeTween/issues/248
- Fixed: foldable animation headers don't update their text correctly when multi-editing or when an object has multiple serialized TweenAnimation fields.
- Fixed: when chaining multiple animations of the same type without manual `startValue` override, the next `startValue` should be automatically calculated from the previous `endValue`. This worked incorrectly for cases when an animation had CycleMode.Yoyo, Incremental, or Rewind. 

## [1.4.7-pro] - 2026-06-08
- Fixed: TweenAnimation.startValue can't be manually modified in the Inspector. https://github.com/KyryloKuzyk/PrimeTween/issues/246

## [1.4.6-pro] - 2026-06-07
### Added
- Added new `CallbackDirection` setting to TweenAnimation that controls whether a callback should be executed on the animation's backward cycle. https://github.com/KyryloKuzyk/PrimeTween/discussions/245
### Fixed
- Fixed: when an animation has a negative timescale and rewinds to the beginning, the OnComplete() should not be invoked.
- Fixed: recompiling scripts in Edit Mode doesn't reset currently running TweenAnimations.

## [1.4.6] - 2026-06-07
### Changed
- VisualElement.Position/Rotation/Scale animations now use VisualElement.style.translate/rotate/scale properties instead of ITransform in Unity 6.2 and newer.

## [1.4.5-pro] - 2026-05-17
### Fixed
- Fixed: saving a prefab while TweenAnimation preview is playing "bakes in" animated preview values into the saved prefab. https://github.com/KyryloKuzyk/PrimeTween/issues/238
- Fixed: when multi-editing TweenAnimations and one of them has targets while the other does not (Callback, for example), TweenAnimationDataPropDrawer throws the `Retrieving array size, but no array was provided` exception.
- Fixed: putting TweenAnimation into an array or a list (TweenAnimation[], List<TweenAnimation>) doesn't update the inspector height and animation headers correctly.
- Fixed: TweenAnimation unconditionally calls `GUI.changed` even if the animation is not running, which results in degraded performance.

## [1.4.4-pro] - 2026-05-08
### Fixed
- Fixed: if Domain Reloading is enabled, TweenAnimationComponent resets the animation on selection change during Play Mode. https://discussions.unity.com/t/primetween-high-performance-animations-and-sequences/926420/448

## [1.4.3-pro] - 2026-04-29
### Fixed
- Fixed: deleting multiple prefabs with TweenAnimationComponent or serialized TweenAnimation immediately restores the deleted prefabs. https://github.com/KyryloKuzyk/PrimeTween/issues/234
- Fixed: after exiting animation preview, the initial value from the scene should be used instead of the animation's `startValue`.
- Fixed: the Undo operation doesn't work after previewing the `endValue` in the Inspector.

## [1.4.2-pro] - 2026-04-23
### Fixed
- Fixed: error message from TweenAnimationComponent when exiting prefab mode. https://github.com/KyryloKuzyk/PrimeTween/issues/232

## [1.4.1-pro] - 2026-04-20
### Fixed
- Fixed: TweenAnimation.cycles can be set to a value lower than -1, which should not be allowed.

## [1.4.0-pro] - 2026-04-14
### Added
- Initial PRO version release.
- TweenAnimationComponent: animate anything with no code: create complex animations, add callbacks, delays, and custom animations entirely from the Inspector.
- TweenAnimation: serialize animations directly in MonoBehaviour scripts: all the power of TweenAnimationComponent, without needing a separate component.
- Job System and Burst Compiler support.
- Per-Object Material Animations with MaterialPropertyBlock.

## [1.4.0] - 2026-04-14
### Fixed
- Fixed: `ToYieldInstruction` can throw an exception if the underlying tween was already reused for another animation. https://github.com/KyryloKuzyk/PrimeTween/issues/220

## [1.3.8] - 2026-02-09
### Added
- Added global `PrimeTweenConfig.warnIfTargetDestroyed` setting. https://github.com/KyryloKuzyk/PrimeTween/discussions/4
- Experimental: added `UpdateType.Manual`. https://github.com/KyryloKuzyk/PrimeTween/discussions/135
### Changed
- `ToYieldInstruction()` no longer throws assertion exceptions if `IEnumerator.Current` is accessed after `MoveNext` returned `false`. https://github.com/KyryloKuzyk/PrimeTween/issues/220
- Tween.Custom overloads that accept TweenSettings are now obsolete. Use TweenSettings<T> overloads instead.

## [1.3.7] - 2025-12-20
### Fixed
- Fixed crash in ARMv7 (32 bits) Android builds. https://github.com/KyryloKuzyk/PrimeTween/issues/217

## [1.3.6] - 2025-12-4
### Added
- Experimental: added `Sequence.GroupCallback` method. https://github.com/KyryloKuzyk/PrimeTween/discussions/90#discussioncomment-14407106
### Changed
- Tween overloads that accept TweenSettings are now obsolete. Use TweenSettings<T> overloads instead.
- Added UnityEngine.Object context to logging. https://github.com/KyryloKuzyk/PrimeTween/discussions/174
- Log onComplete and onUpdate exceptions with Debug.LogException to make it clickable in the console. https://github.com/KyryloKuzyk/PrimeTween/issues/210
- Experimental: renamed ResetBeforeComplete to ResetOnComplete.
### Fixed
- Fixed: 'Complete()' doesn't work with negative 'timeScale'.

## [1.3.5] - 2025-10-15
### Changed
- Sequence's 'CycleMode' has been changed to 'SequenceCycleMode'.
- 'SetRemainingCycles()' now works with negative 'timeScale'. https://github.com/KyryloKuzyk/PrimeTween/issues/203.
- Improved animation debugging in PrimeTweenManager inspector.
### Fixed
- Fixed: inserting animations into a Sequence with negative 'atTime' decreases sequence duration. https://github.com/KyryloKuzyk/PrimeTween/issues/202.
- Fixed: 'startDelay' is ignored when tween's duration is zero. https://github.com/KyryloKuzyk/PrimeTween/issues/200
- Fixed: 'elapsedTimeTotal', 'elapsedTime', and 'progressTotal' are calculated incorrectly for nested tweens.
- Fixed: animating 'ScrollRect.normalizedPosition' can throw exception if 'ScrollRect.content' is null.
- Fixed: if Unity Editor is open for a long time, time measurement gets imprecise when running animations in Edit mode.

## [1.3.3] - 2025-08-10
### Fixed
- SetEase() does not work with a custom AnimationCurve in the adapter. https://github.com/KyryloKuzyk/PrimeTween/issues/175
- Using an invalid Ease value throws an "Invalid ease type" exception and breaks PrimeTween.
- PRIME_TWEEN_SAFETY_CHECKS now works correctly with hot reloading (Recompile And Continue Playing).
- Edit-mode support incorrectly creates PrimeTweenManager when PrimeTween API is used before RuntimeInitializeLoadType.BeforeSceneLoad, which can hide initialization order issues. https://github.com/KyryloKuzyk/PrimeTween/issues/185
- Highlight animations in the Demo do not work in Windows Editor.

## [1.3.2] - 2025-05-18
### Fixed
- Fixed: the 'updateType was ignored' error appears if a tween with default 'updateType' is added to a Sequence. https://github.com/KyryloKuzyk/PrimeTween/issues/171

## [1.3.1] - 2025-04-27
### Added
- Add Edit mode support, so animations can be played in Editor without entering the Play mode. https://github.com/KyryloKuzyk/PrimeTween/discussions/62
- PrimeTween can now be installed via Unity Package Manager.
- Demo project: add 'Play Animation' button to Inspector to preview animations in Edit mode without entering Play mode.
- Add the experimental `ResetAfterComplete()` method to reset animations to the initial value before completion. https://github.com/KyryloKuzyk/PrimeTween/discussions/153
- Add the experimental `PrimeTweenConfig.ManualInitialize()` to initialize PrimeTween before `RuntimeInitializeLoadType.BeforeSceneLoad`. https://github.com/KyryloKuzyk/PrimeTween/issues/150
- Add `Tween.VisualElementOpacity()` method to animate the `VisualElement.style.opacity` property. Also, extend `Tween.Color/Alpha` methods to also work with VisualElement.
### Changed
- Passing `null` to `OnComplete()` is now allowed and no longer results in an error. https://github.com/KyryloKuzyk/PrimeTween/discussions/164
### Fixed
- Fixed: PrimeTween doesn't work after scripts are recompiled while playing in Editor when the 'Recompile And Continue Playing' setting is enabled.

## [1.3.0] - 2025-04-04
### Added
- Add support for updating animations in LateUpdate with the help of the new 'UpdateType updateType' parameter. The available options are Update, LateUpdate, and FixedUpdate. https://github.com/KyryloKuzyk/PrimeTween/issues/138
- Add 'Vector3' overloads to RotationAtSpeed() and LocalRotationAtSpeed() methods.
- Add 'TextFontSize()' to animate 'TextMeshPro.fontSize' property. https://github.com/KyryloKuzyk/PrimeTween/discussions/129
- Add a message to the exception thrown when an invalid ease is provided to `StandardEasing.Evaluate()`. https://github.com/KyryloKuzyk/PrimeTween/issues/151
### Changed
- Change 'bool useFixedUpdate' to 'UpdateType updateType'. The new version comes with an automatic script updater. Please back up your project before updating.
- Make the exception stack trace clickable when custom tween throws an exception. https://github.com/KyryloKuzyk/PrimeTween/issues/119
- Prevent allocations in development builds when  PRIME_TWEEN_SAFETY_CHECKS is enabled. 

## [1.2.2] - 2024-12-05
### Fixed
- Fixed: TextMeshPro animations are not available in Unity 2023. Bug report: https://discussions.unity.com/t/primetween-high-performance-animations-and-sequences/926420/365
- Fixed: Demo project produces compilation errors if Ugui package is not installed.

## [1.2.1] - 2024-11-28
### Fixed
- Fixed: when a new tween is created at the last frame of `ToYieldInstruction()`, coroutine will wait for the wrong tween. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/126

## [1.2.0] - 2024-10-03
### Fixed
- Fixed: sequence.Group() doesn't work correctly after ChainCallback() and InsertCallback(). More info: https://github.com/KyryloKuzyk/PrimeTween/discussions/112

## [1.1.22] - 2024-09-14
### Added
- Add `Easing.Evaluate(float interpolationFactor, Ease ease)` method that gives the ability to evaluate standard eases manually. Previously this method was experimental.
### Fixed
- Fixed: destroying target of a paused tween doesn't release the tween. Bug report: https://github.com/KyryloKuzyk/PrimeTween/discussions/4#discussioncomment-10555636
- Fixed: UPM examples are not compatible with Input System (New).

## [1.1.21] - 2024-08-31
### Added
- Implement GetHashCode() and IEquatable for Tween and Sequence.

## [1.1.20] - 2024-08-12
### Changed
- Change internal tween from 'int' to 'long', which reduces the likelihood of id collisions in apps that run for months or years. Feature request: https://discussions.unity.com/t/926420/291
### Added
- Add 'setImmediately' and 'isRelative' parameters to From() method in [Adapter](https://github.com/KyryloKuzyk/PrimeTween#dotween-adapter). Feature request: https://discussions.unity.com/t/926420/299
### Fixed
- Fixed: Demo scene doesn't work with Input System (New). Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/85
- Fixed (minor): calling Sequence.Complete() when the sequence is in Stater.After doesn't complete the sequence immediately.

## [1.1.19] - 2024-05-29
### Fixed
- Fixed: Tween.TextMaxVisibleCharacters() is not available in Unity 6 because Text Mesh Pro was merged with UGUI.

## [1.1.18] - 2024-05-11
### Fixed
- Fixed: nested sequence updates its children even when it doesn't update self. This resulted in multiple chained jumps to override the first jump. Bug report: https://forum.unity.com/threads/primetween-high-performance-animations-and-sequences.1479609/page-6#post-9802575 

## [1.1.17] - 2024-04-17
### Fixed
- Fixed: Tween.TextMaxVisibleCharacters() throws assertion exception.

## [1.1.16] - 2024-04-16
### Fixed
- Fixed: interpolation factor can be calculated incorrectly when cyclic tween is not started yet. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/63
- Fixed: don't log an error when the child animation setting is the same as the parent Sequence's setting. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/66
- Fixed: enabling PRIME_TWEEN_SAFETY_CHECKS in IL2CPP builds throws exception. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/65
- Fixed: adding experimental define produces compilation error.

## [1.1.15] - 2024-04-07
### Fixed
- Fixed: Tween.GetTweenCount(target) doesn't work for tweens inside sequences. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/60
- Fixed: ShakeSettings.strength property incorrectly displayed in narrow Inspector.
- Fixed: sometimes automatic installation fails and users have to press the 'PrimeTweenInstaller/Install' button to fix it.
- Fixed: review request should appear only after the user presses the Update button in Package Manager. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/58

## [1.1.14] - 2024-03-16
### Added
- Add Tween.VisualElementColor/VisualElementBackgroundColor() to animate colors of UIToolkit components.
- Experimental: add 'double' numeric type support for Tween.Custom(). This feature requires the PRIME_TWEEN_EXPERIMENTAL define in 'Scripting Define Symbols'.
### Changed
- Improve documentation.

## [1.1.13] - 2024-02-23
### Added
- Add sequence.Pause/Play() to adapter.
### Changed
- If sequence child pauses the parent sequence, stop updating Sequence immediately. Other tweens after the current one will not receive an update.

## [1.1.12] - 2024-02-14
### Added
- Add experimental Easing.Evaluate(float, Ease).
- Add DOVirtual.EasedValue() to adapter.
- Add custom Ease.OutBounce strength support to adapter.
### Changed
- The 'warnEndValueEqualsCurrent' setting is now applied on a per-tween basis. Feature request: https://github.com/KyryloKuzyk/PrimeTween/discussions/48

## [1.1.11] - 2024-01-18
### Fixed
- Fixed: calling PrimeTweenConfig.SetTweensCapacity() before PrimeTweenManager is created throws an exception in Editor.
### Changed
- Optimize duplicated shakes on the same target.

## [1.1.10] - 2024-01-15
### Added
- Add sequence.Insert() and sequence.InsertCallback() APIs. Feature request: https://github.com/KyryloKuzyk/PrimeTween/discussions/33
- Add Asset Store review request when updating PrimeTween to a new version.
### Fixed
- Fixed: completing an infinite tween (cycles == -1) evaluates the interpolation factor to -1 and produces wrong animated value. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/38
### Changed
- sequence.Complete() now respects the 'cycles' and 'cycleMode' and works similarly to tween.Complete(). Previuosly, sequence.Complete() completed only the current cycle. 
### Removed
- Remove Tween.PositionOutBounce() experimental API. Use Easing.BounceExact(float amplitude) instead.

## [1.1.9] - 2024-01-09
### Added
- [Adapter](https://github.com/KyryloKuzyk/PrimeTween#dotween-adapter): add 'loopType' parameter to sequence.SetLoops(); add sequence.SetEase(); add SetLink().
### Fixed
- Fixed: sequence.Group() after seqence.Chain() produces a wrong sequence duration (too short) if a grouped tween is longer than the previously chained tween.
- Fixed: sequence.Group(sequence) groups with the first tween in sequence, but should group with the previous tween (or sequence) instead. Now it works the same way as sequence.Group(tween).
- Fixed: sequence.OnComplete() should be called when all sequence children are completed. Previously it was called before the last children update.
- Fixed: setting 'elapsedTime' or 'progress' recursively from Tween.Custom() or tween.OnUpdate() leads to a crash because of stack overflow.
### Changed
- Remove the 'useUnscaledTime' parameter from sequence.ChainDelay(). The parent Sequence controls the 'useUnscaledTime' of all children tweens and sequences, so this parameter is not needed.

## [1.1.8] - 2024-01-05
### Added:
- Add more detailed warnings and errors.
### Fixed
- Fixed: Demo.cs causes a compilation error, preventing PrimeTween from installing correctly.

## [1.1.7] - 2024-01-02
### Fixed
- Fixed: ReusableTween.updateSequence() throws AssertionException when a sequence is running during scene change in the Editor. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/32

## [1.1.6] - 2023-12-29
### Added:
- PrimeTween can now print tween's creation stack trace when an error occurs to make the debugging process a lot easier. This feature requires the 'PRIME_TWEEN_SAFETY_CHECKS' define.
- Add TypewriterAnimatorExample.TypewriterAnimationByWords() to the Demo scene to show an example of how to animate text word-by-word.
### Fixed
- Fixed: shake doesn't restore the position to the initial value if shake's period is less than duration.

## [1.1.5] - 2023-12-14
### Added:
- Add Tween.TextMaxVisibleCharacters(TMP_Text target, ...) method to support simple typewriter animation. Please see the 'Demo.TypewriterAnimatorExample.cs' for a more complex example of text animation that makes pauses after punctuations. 
### Fixed
- Fixed: don't allow to set invalid elapsedTimeTotal and progressTotal values to infinite tweens.

## [1.1.4] - 2023-12-10
### Added:
- Tween/Sequence.timeScale can now be negative to support backward movement (rewind).
- Add 'useFixedUpdate' parameter to update a tween or sequence in the FixedUpdate().
- Release Parametric Easing to production (previously this feature was experimental): https://github.com/KyryloKuzyk/PrimeTween#parametric-easing
### Changed
- The default 'easeBetweenShakes' is now Ease.OutQuad instead of Ease.OutSine.
- The 'useUnscaledTime' parameter now doesn't prevent the abrupt delta time changes when unpausing the Editor to be consistent with the official Unity's behavior.
### Fixed
- Fixed: shakes log the 'warnEndValueEqualsCurrent' warning if object's local position/rotation is Vector3.zero/Quaternion.identity.

## [1.1.3] - 2023-12-06
### Added:
- Add Sequence.OnComplete() API.
### Fixed
- Fixed: nesting multiple empty Sequences may lead to a StackOverflow exception in some cases.
- Fixed: enabling/disabling UI.Slider in Demo scene constantly allocates GC.  

## [1.1.2] - 2023-12-03
### Added:
- Add 'PrimeTweenConfig.warnEndValueEqualsCurrent' setting to warn if the 'endValue' equals to the current animated value.
### Fixed
- Fixed: PrimeTween may log warnings in Editor when exiting Play Mode. 

## [1.1.1] - 2023-11-30
### Added:
- Sequences now support CycleMode.Yoyo and CycleMode.Rewind with the help of Sequence.Create(numCycles, CycleMode **cycleMode**).
- Sequences now support easing that can be applied to the whole Sequence with the help of Sequence.Create(..., Ease **sequenceEase**).
- 'elapsedTime', 'elapsedTimeTotal', 'progress', and 'progressTotal' properties now have setters, so it's possible to manually set the elapsed time of tweens and sequences. Please see the Demo scene for usage example.
- Parent Sequence now controls the isPaused, timeScale, and useUnscaledTime of all its children tweens and sequences.
- Add a warning when tween.SetRemainingCycles() is called on Tween.Delay(). More info: https://discussions.unity.com/t/926420/101.
### Changed
- It's no longer allowed to Stop()/Complete() a tween inside a Sequence. Please Stop()/Complete() the parent Sequence instead.
- It's no longer allowed to await or use the '.ToYieldInstruction()' on tween inside a Sequence. Please use the parent Sequence instead.
- It's no longer allowed to add tweens to a started Sequence.
- It's now allowed to call Tween.StopAll(), Tween.CompleteAll() and Tween.SetPausedAll() from onValueChange, OnUpdate() and OnComplete().
- SetCycles() was renamed to SetRemainingCycles(). To set Sequence cycles, use Sequence.Create(cycles: numCycles).
- Remove 'minExpected' and 'numMaxExpected' parameters from Tween.StopAll/CompleteAll/SetPausedAll() methods.
### Fixed
- Fixed: Tween.GetTweensCount() may return the incorrect result if called from the OnComplete() callback.
- Fixed: MeasureMemoryAllocations.cs example script doesn't ignore its own allocations.

## [1.0.17] - 2023-11-12
### Fixed
- Fixed: the Demo scene doesn't compile if PrimeTween is not installed.

## [1.0.16] - 2023-11-04
### Fixed
- Fixed: Quaternion tweens don't work correctly with CycleMode.Incremental. Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/19

## [1.0.15] - 2023-10-14
### Fixed
- Fixed: the first time Sequence is created, it may play incorrectly in some cases.

## [1.0.14] - 2023-10-02
### Added
- Add methods to animate RectTransform.offsetMin/offsetMax.
- Add sequence.timeScale to set the timeScale for all tweens in a Sequence.
- Add Tween.TweenTimeScale(Sequence) method to animate sequence.timeScale over time.
### Fixed
- Fixed: Unity's Time.unscaledDeltaTime reports the wrong value after unpausing a scene in the Editor.

## [1.0.13] - 2023-09-24
### Fixed
- Fixed: passing a null UnityEngine.Object to 'Tween.' methods causes null ref exception in PrimeTweenManager.Update(). Bug report: https://github.com/KyryloKuzyk/PrimeTween/issues/13

## [1.0.12] - 2023-09-22
### Added
- Experimental: add parametric Easing.Bounce(float strength) and Easing.BounceExact(float magnitude). BounceExact allows to specify the exact bounce amplitude in meters/degrees regardless of the total tween distance. This feature requires the PRIME_TWEEN_EXPERIMENTAL define.
- Add From(fromValue) method to adapter.
- Support parametric OutBack and OutElastic eases in the adapter.
### Changed
- Easing.Elastic: normalize the oscillation period by duration; this ensures the tween has the same period regardless of duration.

## [1.0.11] - 2023-09-21
### Added
- Tween.GlobalTimeScale(), Tween.TweenTimeScale(), and tween.timeScale are no longer experimental.
- Add tween.OnUpdate() to execute a custom callback when the animated value is updated.
- Experimental: add Easing.Overshoot(float strength) and Easing.Elastic(float strength, float normalizedPeriod) methods to customize Ease.OutBounce and Ease.OutElastic.
### Changed
- Tween methods now accept Easing struct instead of AnimationCurve. You can continue using AnimationCurve as before because it is implicitly converted to the Easing struct.
- Ease.OutElastic now works the same as the most popular js and C# tween libraries.
### Fixed
- Add PrimeTween.Demo namespace to Demo scripts.

## [1.0.10] - 2023-09-13
### Added
- Add Tween.XxxAtSpeed() methods to create animations based on speed instead of duration.
- Add Tween.GetTweensCount() method.
### Changed
- Improve performance.

## [1.0.9] - 2023-09-08
### Changed
- Tween.StopAll(null) and Tween.CompleteAll(null) now immediately clean the internal tweens list, so PrimeTweenConfig.SetTweensCapacity() can be called immediately after that.
### Fixed
- Fixed: Tween.ShakeLocalRotation() doesn't work correctly.

## [1.0.8] - 2023-09-07
### Added
- Tween.Delay(), tween.OnComplete(), and sequence.ChainDelay() methods now accept the 'warnIfTargetDestroyed' parameter to control whether PrimeTween should log the error about tween's target destruction. More info: https://github.com/KyryloKuzyk/PrimeTween/discussions/4
### Fixed
- Fix compilation error with PRIME_TWEEN_DOTWEEN_ADAPTER.

## [1.0.7] - 2023-09-01
### Added
- Add 'UI Toolkit' support (com.unity.modules.uielements). All animations from the [ITransitionAnimations](https://docs.unity3d.com/2023.2/Documentation/ScriptReference/UIElements.Experimental.ITransitionAnimations.html) interface are supported. 
- Experimental: add Tween.PositionOutBounce/LocalPositionOutBounce() methods. These methods add the ability to fine-tune the Ease.OutBounce by specifying the exact bounce amplitude, number of bounces, and bounce stiffness.
- Log error when properties of dead tweens and sequences are used.
### Changed
- Rename 'Tween.LocalScale()' methods to 'Tween.Scale()'.
- Rename 'IsAlive' to 'isAlive'.
- Rename 'IsPaused' to 'isPaused'.

## [1.0.5] - 2023-08-29
### Added
- Experimental: add tween.timeScale; Tween.TweenTimeScale(); Tween.GlobalTimeScale().
### Fixed
- Fixed: onComplete callback should not be called if Tween.OnComplete<T>(_target_, ...) has been destroyed.
- Fixed: 'additive' tweens don't work correctly.

## [1.0.4] - 2023-08-22
### Added
- Warn if PrimeTween's API is used in Edit mode (when the scene is not running).
- Experimental: additive tweens.
### Changed
- Move Tween.Custom() 'AnimationCurve' parameter after 'onValueChange' parameter to be consistent with other overloads.
- Move Tween.ShakeCustom/PunchCustom() 'startValue' parameter before 'ShakeSettings' parameter to be consistent with Tween.Custom() methods.
### Fixed
- Normalize Quaternion passed to animation methods.

## [1.0.3] - 2023-08-15
### Added
- Sequence nesting: sequences can be grouped/chained to other sequences.
- Add startValue/endValue overload to all animation methods.
- Add Tween.ShakeCamera().
- Measure memory allocations in the Demo scene.

## [1.0.2] - 2023-05-29
### Added
- All tweens can now be viewed in PrimeTweenManager's inspector.
### Changed
- Tweens are now frame perfect. That is, on a stable framerate, tweens take a deterministic number of frames.

## [1.0.1] - 2023-04-28
### Added
- Add a version of Tween.Custom() that doesn't require passing a tween's target. Please note that this version will most probably generate garbage because of closure allocation.
- Add Tween.EulerAngles/LocalEulerAngles methods to animate rotation beyond 180 degrees.
- Add Demo scene.
### Changed
- Remove Tween.RotationXYZ/LocalRotationXYZ methods because manipulating Euler angles may lead to unexpected results. More info: https://docs.unity3d.com/ScriptReference/Transform-eulerAngles.html
- Tween.Rotation/LocalRotation methods now convert the Vector3 parameter to Quaternion instead of treating it as Euler angles.
### Fixed
- Property drawers don't work correctly with copy-pasting and prefabs.
- Fixed: samples asmdef has dependency duplication that leads to compilation error.
- Fixed: custom curve should not be clamped at the start or the end of the animation.

## [1.0.0] - 2023-04-20
### Added
- Animate anything (UI, Transform, Material, etc.) with zero allocations.
- Group animations in Sequences with zero allocations.
- Shake anything.
- Everything is tweakable from the Inspector.
- Async/await support.
- Coroutines support.
