using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Threading;
using JetBrains.Annotations;
using UnityEngine;

namespace PrimeTween {
    /// <summary>A component that exposes <see cref="TweenAnimation"/> to the scene. Consider using it if you need to reference the animation from other scripts or animations in the scene.<br/>
    /// - Allows authoring and previewing complex animation sequences in the Inspector without writing any code.<br/>
    /// - Allows an animation to be referenced in a scene and played from other MonoBehaviours or UnityEvents.<br/>
    /// - Can play an animation in response to Unity messages like OnEnable and OnDisable.<br/></summary>
    [PublicAPI, SelectionBase]
    public class TweenAnimationComponent : MonoBehaviour {
        [SerializeField] public
            #if !UNITY_6000_5_OR_NEWER
            new
            #endif
            TweenAnimation animation = new TweenAnimation();
        [SerializeField] public UnityMessageAction onEnable;
        [SerializeField] public UnityMessageAction onDisable;

        /// <summary>Defines the action to perform when a Unity message like OnEnable or OnDisable is invoked.</summary>
        public enum UnityMessageAction {
            None, Trigger, SetStateTrue, SetStateFalse, Stop, Reset, Complete
        }

        [EditorBrowsable(EditorBrowsableState.Never)] public void ___Complete()    => GetAnimation()?.Complete();
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___SetPaused(bool isPaused)      { if (GetAnimation() is TweenAnimation a) a.isPaused = isPaused; }
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___SetProgressTotal(float value) { if (GetAnimation() is TweenAnimation a) a.progressTotal = value; }
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___SetState(bool newState)       { if (GetAnimation() is TweenAnimation a) a.state = newState; }
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___Stop()        => GetAnimation()?.Stop();
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___ToggleState() => GetAnimation()?.ToggleState();
        [EditorBrowsable(EditorBrowsableState.Never)] public void ___Trigger()     => GetAnimation()?.Trigger();

        [CanBeNull]
        TweenAnimation GetAnimation() {
            if (animation == null) {
                Debug.LogError($"{nameof(animation)} is null.", this);
            }
            return animation;
        }

        void OnEnable() => ApplyBehaviour(onEnable);
        void OnDisable() {
            bool warnTweenOnDisabledTarget = PrimeTweenConfig.warnTweenOnDisabledTarget;
            PrimeTweenConfig.warnTweenOnDisabledTarget = false;
            ApplyBehaviour(onDisable);
            PrimeTweenConfig.warnTweenOnDisabledTarget = warnTweenOnDisabledTarget;
        }

        void ApplyBehaviour(UnityMessageAction behaviour) {
            #if UNITY_EDITOR
            if (PrimeTweenManager._playModeState == UnityEditor.PlayModeStateChange.ExitingPlayMode) {
                return;
            }
            #endif
            var a = GetAnimation();
            if (a == null) {
                return;
            }
            switch (behaviour) {
                case UnityMessageAction.None:
                    break;
                case UnityMessageAction.Trigger:
                    a.Trigger();
                    break;
                case UnityMessageAction.SetStateTrue:
                    a.state = true;
                    break;
                case UnityMessageAction.SetStateFalse:
                    a.state = false;
                    break;
                case UnityMessageAction.Stop:
                    a.Stop();
                    break;
                case UnityMessageAction.Reset:
                    a.Reset();
                    break;
                case UnityMessageAction.Complete:
                    a.Complete();
                    break;
                default:
                    Debug.LogError($"Invalid {nameof(UnityMessageAction)}: {behaviour}.", this);
                    break;
            }
        }
    }

    /// <summary>A serializable animation which allows authoring and previewing complex animation sequences in the Inspector without writing any code.<br/>
    /// - Allows creating animations right where you need them with no need to set up references in a scene.<br/>
    /// - If animation is reversible, allows you to change the direction of the animation by setting 'state'. No need to keep track of the state yourself, simply choose a new desired direction at any time.<br/>
    /// - Provides ways to tweak how an animation responds to interruptions with <see cref="InterruptionMode"/>.<br/>
    /// <example>
    /// <code>
    /// // Add TweenAnimation to your script, then set the animation up in the Inspector.
    /// [SerializeField] TweenAnimation doorAnimation = new TweenAnimation();
    ///
    /// void Update() {
    ///     if (Input.GetKeyDown(KeyCode.Space)) {
    ///         // Play the animation in response to gameplay events.
    ///         doorAnimation.Trigger();
    ///     }
    /// }
    /// </code>
    /// </example>
    /// </summary>
    [Serializable, PublicAPI] 
    public partial class TweenAnimation
    { // p1 todo add OnComplete?
        // p1 todo add support for TextAnimator typewriter
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        [SerializeField] public List<Data> animations = new List<Data>();

        // 'isReversible' and 'cycles == -1' keep the serialized format of older versions, so older versions can still open the animations saved by this version. They take precedence over '_animationType', which only matters for Overlapping
        [Obsolete("use '" + nameof(animationType) + "' instead.")]
        [SerializeField, HideInInspector] public bool isReversible;
        [SerializeField] internal AnimationType _animationType;

        public AnimationType animationType {
            #pragma warning disable CS0618
            get => GetAnimationType(isReversible, cycles, _animationType);
            set => SetAnimationType(value, ref _animationType, ref isReversible, ref cycles);
            #pragma warning restore CS0618
        }

        internal static void SetAnimationType(AnimationType value, ref AnimationType stored, ref bool isReversible, ref int cycles) {
            // Storing only Overlapping limits any type change to two of the three serialized fields, so the Inspector can link both of them for the prefab Revert/Apply
            stored = value == AnimationType.Overlapping ? AnimationType.Overlapping : AnimationType.Simple;
            isReversible = value == AnimationType.Reversible;
            if (value == AnimationType.Infinite) {
                cycles = -1;
            } else if (cycles == -1) {
                cycles = 1;
            }
        }

        /// The Free version supports only these tween types. Other tween types are shown in the Inspector under the 'Pro' group
        internal static bool IsFreeTweenType(TweenType tweenType) {
            switch (tweenType) {
                case TweenType.Position:
                case TweenType.PositionX:
                case TweenType.PositionY:
                case TweenType.PositionZ:
                case TweenType.LocalPosition:
                case TweenType.LocalPositionX:
                case TweenType.LocalPositionY:
                case TweenType.LocalPositionZ:
                case TweenType.Rotation:
                case TweenType.EulerAngles:
                case TweenType.LocalRotation:
                case TweenType.LocalEulerAngles:
                case TweenType.Scale:
                case TweenType.Delay:
                    return true;
                default:
                    return false;
            }
        }

        internal static AnimationType GetAnimationType(bool isReversible, int cycles, AnimationType stored) {
            if (isReversible) {
                return AnimationType.Reversible;
            }
            if (stored == AnimationType.Overlapping) {
                return AnimationType.Overlapping;
            }
            return cycles == -1 ? AnimationType.Infinite : AnimationType.Simple;
        }

        /// <summary>Defines how <see cref="TweenAnimation"/> responds to <see cref="state"/> changes and <see cref="Trigger"/>.</summary>
        public enum AnimationType : byte {
            [Tooltip("Plays the animation from the beginning. Triggering the animation while it's playing applies '" + nameof(interruptionMode) + "'.")]
            Simple,
            [Tooltip("Use for toggle animations (e.g., open/close or show/hide).\n\n" +
                     "Set 'state = true' to play forward and 'state = false' to reverse — no need for a separate direction variable. Or use 'Trigger()' to toggle the current state.")]
            Reversible,
            [Tooltip("Plays the animation infinitely. '" + nameof(cycles) + "' is always -1.")]
            Infinite,
            [Tooltip("Triggering the animation while it's playing plays a new animation on top of the playing one. The previous animation continues playing until its end and can no longer be controlled.\n\n" +
                     "Use with additive tweens to blend and accumulate their changes. Additive tweens also accumulate when a completed animation is played again, instead of restarting from the initial value.\n\n" +
                     "Overlapping animations can't be paused and ignore '" + nameof(interruptionMode) + "'.")]
            Overlapping
        }

        /// <summary>See <see cref="Trigger"/> method's documentation to know when the <see cref="InterruptionMode"/> is applied.</summary>
        [Tooltip("Controls how the animation behaves when interrupted.")]
        [SerializeField] public InterruptionMode interruptionMode;

        [Tooltip(Constants.cyclesTooltip)]
        [SerializeField] public int cycles = 1;

        [Tooltip("Controls how the animation behaves with multiple cycles or multiple successive plays.")]
        [SerializeField] public Sequence.SequenceCycleMode cycleMode; // p2 todo if sequenceEase is Linear or Default, Yoyo and Rewind are the same. I can collapse these options into one enum in this case

        [Tooltip("If enabled, triggering the animation again while it's already playing will be ignored.")]
        [SerializeField] public bool ignoreDuplicateTrigger;

        [Tooltip("Instantly resets the animation to the beginning upon completion.")]
        [SerializeField] public bool resetOnCompletion;

        [Tooltip("Easing curve of the entire '" + nameof(TweenAnimation) + "'. Different easing curves produce a different animation 'feeling'.\n\n" +
                 "Easing is clamped to [0:1] range and is applied to the whole animation's timeline.")]
        [SerializeField] public Ease sequenceEase = Ease.Linear;

        [Tooltip(Constants.unscaledTimeTooltip)]
        [SerializeField] public bool useUnscaledTime;

        [Tooltip(Constants.updateTypeTooltip)]
        [SerializeField] internal _UpdateType _updateType;

        [Tooltip("Custom timescale.")]
        [SerializeField] internal float _timeScale = 1f;

        [SerializeField] internal UnityEngine.Object context;



        #if UNITY_EDITOR
        [NonSerialized] ValueWrapper?[][] _iniValues;
        [NonSerialized] internal HeaderData[] _headers;

        /// p2 todo headers should display "---" when multi-editing different animations
        /// p2 todo: add custom tween target name and property name; add material property name
        internal struct HeaderData {
            internal Operation operation;
            internal TweenType tweenType;
            internal string targetName;
            internal GUIContent guiContent;
            internal float insertionTime;
            internal float duration;
            internal int cycles;
            internal string eventNames;
        }
        #endif

        /// <summary>Controls the Unity event function that updates the animation. The default is MonoBehaviour.Update().</summary>
        public UpdateType updateType { get => new UpdateType(_updateType); set => _updateType = value.enumValue; }

        [NonSerialized] bool _state;

        /// <summary>The logical state of the animation. Instead of keeping track of the animation state manually, you can rely on animation state directly.<br/>
        /// State means different things depending on the animation type. Changing state applies <see cref="interruptionMode"/>.<br/><br/>
        /// Simple animations: returns <c>true</c> if an animation is currently playing.<br/>
        /// Infinite animations: returns <c>true</c> if an animation is currently playing and NOT being interrupted by <see cref="interruptionMode"/>.<br/>
        /// Reversible animations (<see cref="AnimationType.Reversible"/>): returns <c>true</c> if the animation is moving forward OR already at the end. Changing state changes animation direction.<br/>
        ///
        /// <example>
        /// <code>
        /// [SerializeField] TweenAnimation doorAnimation = new TweenAnimation();
        /// [SerializeField] TweenAnimation infiniteGlowAnimation = new TweenAnimation();
        ///
        /// public void SetDoorState(bool isOpen) {
        ///     // Apply the animation state with no additional checks. TweenAnimation will only play when the state changes
        ///     doorAnimation.state = isOpen;
        /// }
        ///
        /// public void EnableGlow(bool isEnabled) {
        ///     // Using InterruptionMode.Default will seamlessly transition the infinite animation between active and inactive states
        ///     infiniteGlowAnimation.state = isEnabled;
        /// }
        /// </code>
        /// </example>
        /// </summary>
        public bool state {
            get {
                if (animationType == AnimationType.Reversible
                    || (animationType == AnimationType.Infinite && isAlive)
                    ) {
                    return _state;
                }

                return isAlive;
            }
            set {
                if (!TryManipulate()) {
                    return;
                }
                if (isAlive && !_sequence.root.ValidateIsNotCompleting()) {
                    return;
                }
                if (state != value) {
                    if (isAlive) {
                        // Interrupt() sets the state itself. For example, a simple animation completed by the interruption keeps its _state true
                        if (!Interrupt(value)) {
                            return;
                        }
                    } else {
                        if (animationType == AnimationType.Overlapping) {
                            SetState(false); // additive tweens accumulate on top of the completed play instead of reverting its delta
                        }
                        CreateSequenceAndApplyDirection(value);
                        SetState(value);
                    }
                    Assert.IsTrue(state == value || !isAlive); // a callback can stop a non-reversible animation while it's being created
                }
            }
        }

        // returns false if the interruption is not supported
        bool Interrupt(bool newState) {
            Assert.IsTrue(isAlive);
            Assert.IsTrue(CanManipulate());
            SanitiseInterruptionMode(animationType, ref interruptionMode);
            if (animationType == AnimationType.Infinite) {
                if (newState) {
                    _sequence.SetRemainingCycles(-1);
                    SetState(true);
                } else {
                    if (interruptionMode == InterruptionMode.Reset) {
                        Reset();
                    } else {
                        // StopAtStart
                        if (cycleMode == Sequence.SequenceCycleMode.Restart) {
                            _sequence.SetRemainingCycles(1);
                        } else {
                            _sequence.SetRemainingCycles(false);
                        }
                        SetState(false);
                    }
                }
            } else if (animationType == AnimationType.Reversible) {
                if (interruptionMode == InterruptionMode.Complete) {
                    _sequence.Stop();
                    CreateSequenceAndApplyDirection(newState);
                    SetState(newState);
                    Complete();
                } else {
                    // Rewind
                    _sequence.timeScale *= -1f;
                    SetState(!state);
                }
            } else { // simple or overlapping
                if (newState) {
                    Debug.LogError("Animation is in an invalid state. It was alive while setting 'state = true'. Please file a bug report: https://github.com/KyryloKuzyk/PrimeTween/issues");
                } else {
                    if (animationType == AnimationType.Simple && interruptionMode == InterruptionMode.Complete) {
                        Complete();
                    } else {
                        Reset();
                    }
                }
            }
            return true;
        }

        [System.Diagnostics.Conditional("_")]
        void print(string msg, UnityEngine.Object ctx = null) {
            // Debug.Log($"[{Time.frameCount}]  {(context != null ? context.name : string.Empty)}  {msg} ", ctx ?? context);
        }

        internal void SetState(bool? value, int depth = 0) {

            bool newVal = value ?? false;
            /*if (_state != newVal) {
                print($"SetState:{newVal}");
            }*/
            _state = newVal;

        }



        internal const float minTimeScale = 0.01f;
        internal Sequence _sequence;
        #if UNITY_EDITOR
        internal static bool isPreviewing; // this should be a static field. For example, when GameObject has multiple TweenAnimations, if we're previewing one animation, other animations should not save start values and should be disabled in Inspector
        internal static (int id, int keyboardControl, TweenAnimation animation, string propertyPath, Data? iniData) _endValueHighlightData;

        internal static void ResetHighlightData() {
            if (_endValueHighlightData.keyboardControl == GUIUtility.keyboardControl) {
                GUIUtility.keyboardControl = 0; // reset the currently highlighted inspector property
            }
            if (_endValueHighlightData.iniData.HasValue && _endValueHighlightData.animation != null) {
                var iniData = _endValueHighlightData.iniData.Value;
                for (int i = 0; i < iniData.targets.Count; i++) {
                    // Debug.Log($"restore ini val after endValue preview {iniData.targets[i]?.name} {iniData.startValue}");
                    var tween = iniData.StartTweenOrLogError(_endValueHighlightData.animation, i);
                    if (tween.isAliveInternal) {
                        tween.elapsedTime = 0f;
                        tween.Stop();
                    }
                }
            }
            _endValueHighlightData = default;
        }
        #endif

        /// <summary>An animation is 'alive' when it has been played and has not stopped and has not completed yet. A paused animation is also considered 'alive'.</summary>
        public bool isAlive => _sequence.isAlive;

        /// <summary>Stops the animation.</summary>
        public void Stop() {
            // print("Stop");
            if (isAlive) { // a stopped animation keeps its _state, which tells where the animation left its targets
                // A simple animation stopped at the end is the same as a completed one, so its _state stays true. Its _state is already false if resetOnCompletion has moved the targets to the start
                bool isSimpleOrOverlapping = animationType == AnimationType.Simple || animationType == AnimationType.Overlapping;
                bool isAtEnd = animationType == AnimationType.Reversible ? _state : isSimpleOrOverlapping && _state && _sequence.progressTotal >= 1f; // unlike elapsedTimeTotal, progressTotal of a zero-duration sequence is 0 until it's updated
                _sequence.Stop();
                if (animationType != AnimationType.Reversible) {
                    SetState(isAtEnd);
                }
            }
        }

        /// <summary>Immediately completes the animation. See also <see cref="Tween.Complete"/>.</summary>
        public void Complete() {
            // print("Complete");
            if (isAlive && animationType == AnimationType.Infinite && cycleMode != Sequence.SequenceCycleMode.Restart && (_sequence.cyclesTotal == -1 ? _sequence.cyclesDone : _sequence.cyclesTotal - 1) % 2 != 0) {
                SetState(false); // an infinite animation completes its current cycle (or the last cycle set by SetRemainingCycles()), and a backward cycle ends at the start
            }
            _sequence.Complete();
        }

        const string _setRemainingCyclesNotSupportedWithReversible = "Reversible animations don't support " + nameof(SetRemainingCycles);
        internal const string overlappingPauseError = "An overlapping animation can't be paused because the previous plays can no longer be controlled and continue playing until their end.";

        /// <summary>See also <see cref="Tween.SetRemainingCycles(int)"/>.</summary>
        public void SetRemainingCycles(int cycles) {
            if (animationType == AnimationType.Reversible) {
                Debug.LogError(_setRemainingCyclesNotSupportedWithReversible);
                return;
            }
            _sequence.SetRemainingCycles(cycles);
        }

        /// <summary>See also <see cref="Tween.SetRemainingCycles(bool)"/>.</summary>
        public void SetRemainingCycles(bool stopAtEndValue) {
            if (animationType == AnimationType.Reversible) {
                Debug.LogError(_setRemainingCyclesNotSupportedWithReversible);
                return;
            }
            _sequence.SetRemainingCycles(stopAtEndValue);
        }

        /// <summary>The number of completed cycles.</summary>
        public int cyclesDone => _sequence.cyclesDone;
        /// <summary>The total number of cycles. Returns -1 to indicate an infinite number of cycles.</summary>
        public int cyclesTotal => _sequence.cyclesTotal;

        [NonSerialized] bool _isPaused;
        /// <summary>Gets or sets whether the animation is paused.</summary>
        public bool isPaused {
            get => _isPaused;
            set {
                if (value && animationType == AnimationType.Overlapping) {
                    Log(LogType.Error, overlappingPauseError);
                    return;
                }
                SetPaused(value);
            }
        }

        // The Inspector pauses overlapping animations to scrub them, and unpauses them before triggering
        internal void SetPaused(bool value) {
            _isPaused = value;
            if (_sequence.isAlive) {
                _sequence.isPaused = value;
            }
        }

        /// <summary>Custom timeScale.</summary>
        public float timeScale { // p2 todo add Tween.TweenTimeScale(TweenAnimation)? Or Custom animation can be used instead?
            get => _timeScale;
            set {
                if (value < minTimeScale) {
                    Log(LogType.Error, $"{nameof(timeScale)} can't be less than {minTimeScale}.");
                    value = minTimeScale;
                }
                if (float.IsNaN(value) || float.IsInfinity(value)) {
                    throw new ArgumentException($"Invalid {nameof(timeScale)}: {value}.");
                }
                _timeScale = value;
                if (_sequence.isAlive) {
                    _sequence.timeScale = value;
                }
            }
        }

        /// <summary>The duration of one cycle.</summary>
        public float duration => _sequence.duration;
        /// <summary>The duration of all cycles. If the <see cref="cycles"/> == -1, returns <see cref="float.PositiveInfinity"/>.</summary>
        public float durationTotal => _sequence.durationTotal;
        /// <summary>Elapsed time of the current cycle.</summary>
        public float elapsedTime {
            get => _sequence.elapsedTime;
            set => _sequence.elapsedTime = value;
        }
        /// <summary>Elapsed time of all cycles.</summary>
        public float elapsedTimeTotal {
            get => _sequence.elapsedTimeTotal;
            set => _sequence.elapsedTimeTotal = value;
        }

        /// <summary>Normalized progress of the current cycle expressed in the 0..1 range.</summary>
        public float progress {
            get {
                if (!_sequence.root.ValidateIsAlive()) {
                    Debug.LogError(Constants.useProgressTotalInstead);
                    return 0f;
                }
                float res = _sequence.progress;
                return _sequence.root.tween.data.isSequenceInverted ? 1f - res : res;
            }
            set {
                if (!_sequence.root.ValidateIsAlive()) {
                    Debug.LogError(Constants.useProgressTotalInstead);
                    return;
                }
                if (_sequence.root.tween.data.isSequenceInverted) {
                    _sequence.progress = 1f - value;
                } else {
                    _sequence.progress = value;
                }
            }
        }

        /// <summary>Normalized progress of all cycles expressed in the 0..1 range. Can be accessed and set even if animation is not <see cref="isAlive"/>.</summary>
        public float progressTotal {
            get {
                if (!isAlive) {
                    return state ? 1f : 0f;
                }
                float totalProgress = _sequence.progressTotal;
                return _sequence.root.tween.data.isSequenceInverted ? 1f - totalProgress : totalProgress;
            }
            set => SetProgressTotal(value, true);
        }

        internal void SetProgressTotal(float value, bool autoStop) {
            if (!isAlive) {
                if (value >= 1f && state) {
                    return;
                }
                if (value <= 0f && !state) {
                    return;
                }
                // Not Trigger(), because the 'state' setter makes additive tweens of an overlapping animation accumulate, and setting the progress should be idempotent
                bool newState = !state;
                CreateSequenceAndApplyDirection(newState);
                SetState(newState);
            }
            _sequence.progressTotal = _sequence.root.tween.data.isSequenceInverted ? 1f - value : value;
            if (isAlive && (value >= 1f || value <= 0f)) {
                if (animationType == AnimationType.Reversible || animationType == AnimationType.Infinite) {
                    // _state of a simple animation stays true while it's alive, and Stop() sets it to whether the animation stopped at the end
                    SetState(animationType == AnimationType.Reversible && value >= 1f);
                }
                if (autoStop) {
                    Stop();
                }
            }
        }

        /// <summary>Use this method to wait for the animation in coroutines.</summary>
        public IEnumerator ToYieldInstruction() => _sequence.ToYieldInstruction();

        #if UNITASK_INSTALLED
        public static implicit operator Cysharp.Threading.Tasks.UniTask(TweenAnimation tweenAnimation) => tweenAnimation.ToUniTask();
        public async Cysharp.Threading.Tasks.UniTask ToUniTask() => await _sequence;
        #endif

        /// <inheritdoc cref="Tween.SetCancellationToken"/>
        public TweenAnimation SetCancellationToken(CancellationToken cancellationToken, TweenSettings.CancellationMode? cancellationMode = default) {
            _sequence.SetCancellationToken(cancellationToken, cancellationMode);
            return this;
        }

        #pragma warning disable CS0618 // Type or member is obsolete
        public Tween.TweenAwaiter GetAwaiter() => _sequence.GetAwaiter();
        #pragma warning restore CS0618

        /// <summary>Toggles animation state. Equivalent to calling 'animation.state = !animation.state'.</summary>
        public TweenAnimation ToggleState() {
            state = !state;
            return this;
        }

        /// <summary>Triggers the animation. The resulting animation state depends on the animation type (simple, reversible, or infinite). If the animation is already playing, applies <see cref="interruptionMode"/>.
        /// Simple and infinite animations: plays the animation from the beginning.<br/>
        /// Reversible animations: changes the direction.<br/></summary>
        public TweenAnimation Trigger() {
            if (!TryManipulate()) {
                return this;
            }
            if (isAlive) {
                if (ignoreDuplicateTrigger) {
                    print("ignoreDuplicateTrigger");
                } else {
                    if (animationType == AnimationType.Overlapping) {
                        // The abandoned sequence plays until its end, so its resetOnCompletion callback should not reset the _state of the new sequence
                        var abandonedRoot = _sequence.root.tween;
                        abandonedRoot.onComplete = null;
                        abandonedRoot.onCompleteCallback = null;
                        abandonedRoot.onCompleteTarget = null;
                        _sequence.isPaused = false; // isPaused can't reach the abandoned sequence later, so it would stay paused forever
                        _sequence = default;
                        SetState(false); // additive tweens of the new sequence start from zero delta
                        CreateSequenceAndApplyDirection(true);
                        SetState(true);
                    } else if (animationType == AnimationType.Simple && interruptionMode == InterruptionMode.Default) {
                        _sequence.Stop();
                        SetState(false);
                        CreateSequenceAndApplyDirection(true);
                        SetState(true);
                    } else {
                        Interrupt(!state);
                    }
                }
            } else {
                ToggleState();
            }
            return this;
        }

        internal Sequence CreateSequenceAndBackupStartValues(int depth = 0) {
            #if UNITY_EDITOR
            if (!Application.isPlaying && animations != null && _iniValues == null) {
                _iniValues = new ValueWrapper?[animations.Count][];
                for (int i = 0; i < animations.Count; i++) {
                    var data = animations[i];
                    var targets = data.targets;
                    if (targets != null) {
                        var iniValues = new ValueWrapper?[targets.Count];
                        for (int targetIndex = 0; targetIndex < targets.Count; targetIndex++) {
                            iniValues[targetIndex] = GetCurrentValue(data.operation, targets[targetIndex], data.tweenType,
                                null, -1
                            );
                            // print($"{(context != null ? context.name : string.Empty)} save ini val {targets[targetIndex]?.name} {iniValues[targetIndex]} {data.tweenType}", targets[targetIndex] ?? context);
                        }
                        _iniValues[i] = iniValues;
                    }
                }
            }
            #endif

            return CreateSequence(depth);
        }

        internal void CreateSequenceAndApplyDirection(bool newState) {
            // print($"CreateSequenceAndApplyDirection {newState}");
            Assert.IsTrue(CanManipulate());
            Assert.IsFalse(isAlive);

            #if UNITY_EDITOR
            isPreviewing = true;
            ResetHighlightData();
            PrimeTweenManager.Instance.TryAddCurrentTweenAnimation(this);
            #endif

            _sequence = CreateSequenceAndBackupStartValues();
            if (!isAlive) {
                return;
            }

            bool isBackward = animationType == AnimationType.Reversible && !newState;
            // print($"ApplyDirection isBackward {isBackward}");
            TweenData.ResetSequence(_sequence.root.tween, isBackward);
            if (!isAlive) {
                return; // a callback invoked by the reset stopped the animation
            }
            if (isBackward) {
                TweenData.InvertSequence(_sequence);
            } else if (resetOnCompletion && CanResetOnComplete()) {
                _sequence.root.ResetOnCompletion();
            }

            if (resetOnCompletion && CanResetOnComplete()) {
                _sequence.OnComplete(this, x => x.SetState(false), warnIfTargetDestroyed: false);
            }
        }


        internal bool CanManipulate() {
            if (_sequence.isAlive && !_sequence.root.tween.data.canManipulate()) {
                return false;
            }
            return true;
        }

        bool TryManipulate() {
            if (!CanManipulate()) {
                Log(LogType.Error, Constants.cantManipulateNested);
                return false;
            }
            return true;
        }

        internal static bool SanitiseCycles(AnimationType type, ref int cycles) {
            bool isReversible = type == AnimationType.Reversible;
            if (isReversible || type == AnimationType.Overlapping) {
                if (cycles < 1) {
                    cycles = 1;
                    return true;
                }
                if (isReversible && cycles % 2 == 0) {
                    cycles--;
                    return true;
                }
            } else if (cycles < -1) {
                cycles = -1;
                return true;
            }
            return false;
        }

        internal static bool SanitiseCycleMode(AnimationType type, ref Sequence.SequenceCycleMode cycleMode) {
            if (type == AnimationType.Reversible && cycleMode == Sequence.SequenceCycleMode.Restart) {
                cycleMode = Sequence.SequenceCycleMode.YoyoChildren;
                return true;
            }
            return false;
        }

        internal static bool SanitiseInterruptionMode(AnimationType type, ref InterruptionMode mode) {
            if (type == AnimationType.Infinite) {
                if (mode == InterruptionMode.Complete) {
                    mode = InterruptionMode.Reset;
                    return true;
                }
            } else if (type == AnimationType.Reversible) {
                if (mode == InterruptionMode.Reset) {
                    mode = InterruptionMode.Complete;
                    return true;
                }
            }
            return false;
        }

        Sequence CreateSequence(int depth = 0) {
            var anims = animations;
            if (anims == null) {
                Log(LogType.Error, $"'{nameof(anims)}' is null.");
                return default;
            }

            SanitiseCycles(animationType, ref cycles);
            SanitiseCycleMode(animationType, ref cycleMode);
            var seq = Sequence.Create(cycles, cycleMode, sequenceEase, useUnscaledTime, updateType);
            if (!seq.isAlive) {
                return seq;
            }
            Assert.AreEqual(PrimeTweenManager.dummyTarget, seq.root.tween.managedData.target);
            seq.root.tween.managedData.target = this;
            Assert.IsNull(seq.root.tween.customOnValueChange);
            seq.root.tween.customOnValueChange = context;
            seq.timeScale = Mathf.Max(minTimeScale, _timeScale);
            seq.isPaused = _isPaused;
            for (int i = 0; i < anims.Count; i++) {
                Data data = anims[i];
                if (data.operation == Operation.Disabled || data.tweenType == TweenType.Disabled) {
                    continue;
                }

                {
                    int count = Math.Max(1, data.targets?.Count ?? 0);
                    for (int targetIndex = 0; targetIndex < count; targetIndex++) {
                        string error = string.Empty;
                        Tween tween = data.StartTween(ref error, this, targetIndex);
                        if (!tween.isAliveInternal) {
                            LogError(error);
                            continue;
                        }
                        #if UNITY_EDITOR
                        tween.tween.indexInTweenAnimation = i;
                        #endif
                        if (targetIndex == 0) {
                            switch (data.operation) {
                                case Operation.Insert:
                                    seq.Insert(data.startTime, tween);
                                    break;
                                case Operation.Chain:
                                    seq.Chain(tween);
                                    break;
                                case Operation.Group:
                                    seq.Group(tween);
                                    break;
                                default:
                                    LogError($"Invalid {nameof(Operation)}: {data.operation}.");
                                    continue;
                            }
                        } else {
                            // Tweens on the first target should adhere to the actual operation, while all later tweens should be grouped to the first one
                            seq.Group(tween);
                        }
                    }
                }

                void LogError(string msg) {
                    if (!string.IsNullOrEmpty(msg)) {
                        Log(LogType.Error, $"{nameof(TweenAnimation)} is not set up correctly at index {i}. {msg}");
                    }
                }
            }
            return seq;
        }

        void Log(LogType type, string msg, UnityEngine.Object logContext = null) {
            object log = $"{(context != null ? context.name : string.Empty)} {msg}";
            Debug.unityLogger.Log(type, log, logContext ?? context);
        }

        internal bool CanResetOnComplete() => cycles >= 1 && (cycleMode == Sequence.SequenceCycleMode.Restart || cycles % 2 != 0) && animationType != AnimationType.Reversible;

        /// <summary>Defines how an animation is added to a sequence.</summary>
        /// <seealso cref="Sequence.Chain(Tween)"/> <seealso cref="Sequence.Group(Tween)"/> <seealso cref="Sequence.Insert(float, Tween)"/>
        public enum Operation : sbyte { Disabled = -1, Chain, Group, Insert }

        /// <summary>Controls how <see cref="TweenAnimation"/> behaves when interrupted.</summary>
        /// <seealso cref="state"/> <seealso cref="TweenAnimation.interruptionMode"/>
        public enum InterruptionMode : byte {
            [Tooltip("Simple animations: restart the animation from the beginning.\n\n" +
                     "Reversible animations: seamlessly change the direction.\n\n" +
                     "Infinite animations: continue playing the current loop until its end. Use this mode to prevent abrupt changes and smoothly stop infinite animations.")]
            Default,
            [Tooltip("Completes the animation.")]
            Complete,
            [Tooltip("Instantly resets the animation to the beginning.")]
            Reset
        }

        internal void PlayIfNotAlive() {
            if (!isAlive) {
                Trigger();
            }
        }

        /// <summary>Instantly resets the animation to the beginning.</summary>
        public void Reset() {
            if (!TryManipulate()) {
                return;
            }
            // print("Reset");
            if (Application.isPlaying) {
                if (!isAlive) {
                    if (animations == null) {
                        Log(LogType.Error, $"'{nameof(animations)}' is null.");
                        return;
                    }
                    _sequence = CreateSequence();
                }
                if (isAlive) {
                    // 'toEnd' is relative to the playback direction, and the sequence of a reversible animation playing backward is inverted
                    TweenData.ResetSequence(_sequence.root.tween, _sequence.root.tween.data.isSequenceInverted);
                }
                SetState(false);
            }
            #if UNITY_EDITOR
            else {
                if (PrimeTweenManager.HasInstance) {
                    // Stop the sequences abandoned by an overlapping animation so they don't change the restored initial values
                    PrimeTweenManager.ProcessAll(this, tween => {
                        if (tween.data.IsMainSequenceRoot()) {
                            new Sequence(tween.sequence).Stop();
                        }
                        return true;
                    }, true);
                }
                SetState(null);
                isPreviewing = false;
                ResetHighlightData();
                isPaused = false;
                ResetComponentsInEditor(0);
            }
            #endif
            _sequence.Stop();
        }

        #if UNITY_EDITOR
        void ResetComponentsInEditor(int depth) {
            if (animations != null) {
                // restore ini values
                if (_iniValues != null) { // can be null if scrubbed to the beginning manually, then deselected
                    for (int i = 0; i < animations.Count; i++) {
                        var data = animations[i];
                        if (_iniValues.Length == animations.Count) {
                            var iniValues = _iniValues[i];
                            if (iniValues != null) {
                                for (int targetIndex = 0; targetIndex < data.targets.Count && targetIndex < iniValues.Length; targetIndex++) {
                                    if (iniValues[targetIndex] is ValueWrapper iniVal) {
                                        // A constant tween ends at the initial value regardless of cycles, cycleMode, and ease. For example, an even number of Yoyo cycles ends at the startValue
                                        data.startValue = iniVal;
                                        data.endValue = iniVal;
                                        data.StartTweenOrLogError(this, targetIndex).Complete();

                                        // var target = data.targets[targetIndex];
                                        // print($"{i}/{animations.Count} restore ini val {(target != null ? target.name : "NULL_OR_DESTROYED")} {iniVal} {data.tweenType}", target);
                                    }
                                }
                            }
                        } else {
                            Log(LogType.Error, $"Invalid number of _iniValues: {_iniValues.Length} != {animations.Count}");
                        }
                    }
                    _iniValues = null;
                }

            }
        }
        #endif


        internal static ValueWrapper? GetCurrentValue(Operation operation, [CanBeNull] UnityEngine.Object target, TweenType tweenType, string stringParam, int materialIndex) {
            if (operation == Operation.Disabled) {
                return null;
            }
            if (!IsFreeTweenType(tweenType)) {
                return null;
            }
            Type targetType;
            try {
                targetType = Utils.TweenTypeToTweenData(tweenType).Item2;
            } catch {
                return null;
            }
            {
                if (target == null || targetType == null || !targetType.IsAssignableFrom(target.GetType())) {
                    return null;
                }
            }

            TweenType? remapped = RemapToQuaternionType(tweenType);
            TweenType? RemapToQuaternionType(TweenType t) {
                switch (t) {
                    case TweenType.Rotation: return TweenType.RotationQuaternion;
                    case TweenType.LocalRotation: return TweenType.LocalRotationQuaternion;
                    default: return null;
                }
            }

            var blob = new ColdData.Blob();
            if (remapped.HasValue) {
                return Utils.GetAnimatedValue(target, remapped.Value, ref blob).quaternion.eulerAngles.ToContainer();
            }
            return Utils.GetAnimatedValue(target, tweenType, ref blob);
        }

        /// <summary>Internal animation data. Typically, it should not be modified directly. Use only for advanced use cases.</summary>
        [Serializable, EditorBrowsable(EditorBrowsableState.Advanced)]
        public struct Data {
            [SerializeField] public Operation operation;
            [SerializeField] public float startTime;
            [SerializeField]
            internal
                TweenType tweenType;
            [SerializeField] public List<UnityEngine.Object> targets;
            [SerializeField] internal bool boolParam; // hasStartValue / callbackWarnIfTargetDestroyed / shakeEnableFalloff
            [SerializeField, Tooltip("Start value of an animation. Enable to set the start value manually.\n\n" +
                                     "Disable to use the current value (only works in Edit Mode).")]
            public ValueWrapper startValue;                                                         // Or 'xyz': shakeCustomStartValue | 'w': shakeFrequency
            [SerializeField, Tooltip("End value of an animation")] public ValueWrapper endValue;    // Or 'x': shakeCameraStrengthFactor / 'xyz': shakeStrength | 'w': shakeAsymmetry / 'xyz': additive deltaValue
            [SerializeField] public float duration;
            [SerializeField, Tooltip(Constants.easeTooltip)] public Ease ease; // Or ShakeSettings.falloffEase
            [SerializeField] public AnimationCurve customEase;
            [SerializeField, Tooltip(Constants.cyclesTooltip)] public int cycles; // p1 todo allow having multiple cycles for TweenAnimationComponent?
            [SerializeField, Tooltip(Constants.cycleModeTooltip)] public CycleMode cycleMode;



            internal Data(Data other) {
                this = other;
            }


            public bool hasStartValue { get => boolParam; set => boolParam = value; }
            TweenSettings<float> settingsFloat => CreateSettings(startValue.single, endValue.single);
            TweenSettings<Vector3> settingsVector3 => CreateSettings(startValue.vector3, endValue.vector3);
            TweenSettings<T> CreateSettings<T>(T start, T end) where T : struct {
                if (cycles < 0) {
                    Debug.LogError(Constants.infiniteTweenInSequenceError);
                    cycles = 1;
                }
                TweenSettings settings = new TweenSettings(duration, ease, ease == Ease.Custom ? customEase : (Easing?)null, cycles, cycleMode);
                return new TweenSettings<T>(start, end, settings);
            }


            internal bool GetUnityTarget<T>(out T tweenTarget, ref string error, int targetIndex) where T : UnityEngine.Object {
                var target = targets[targetIndex];
                if (target == null) {
                    tweenTarget = null;
                    if (Application.isPlaying && !PrimeTweenManager.HasPrefabStage()) {
                        error = $"'target' ({typeof(T)}) is null or destroyed.";
                    }
                    return false;
                }

                tweenTarget = target as T;
                if (tweenTarget == null) {
                    error = $"'target' type mismatch: expected ({typeof(T)}), but was {target.GetType()}.";
                    return false;
                }
                return true;
            }


            internal Tween StartTweenOrLogError(TweenAnimation ctx, int i) {
                string error = string.Empty;
                var res = StartTween(ref error, ctx, i);
                if (res.isAliveInternal) {
                    return res;
                } else if (!string.IsNullOrEmpty(error)) {
                    Debug.LogError(error);
                }
                return default;
            }

            internal Tween StartTween(ref string err, TweenAnimation ctx, int i) {
                switch (tweenType) {
                    case TweenType.Delay: return Tween.Delay(duration);
                    case TweenType.EulerAngles: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.EulerAngles(tweenTarget, settingsVector3) : default; }
                    case TweenType.LocalEulerAngles: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalEulerAngles(tweenTarget, settingsVector3) : default; }


                    // CODE GENERATOR BEGIN
                    case TweenType.LocalRotation: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalRotation(tweenTarget, settingsVector3) : default; }
                    case TweenType.Rotation: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Rotation(tweenTarget, settingsVector3) : default; }
                    case TweenType.Position: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Position(tweenTarget, settingsVector3) : default; }
                    case TweenType.PositionX: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionX(tweenTarget, settingsFloat) : default; }
                    case TweenType.PositionY: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionY(tweenTarget, settingsFloat) : default; }
                    case TweenType.PositionZ: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.PositionZ(tweenTarget, settingsFloat) : default; }
                    case TweenType.LocalPosition: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPosition(tweenTarget, settingsVector3) : default; }
                    case TweenType.LocalPositionX: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionX(tweenTarget, settingsFloat) : default; }
                    case TweenType.LocalPositionY: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionY(tweenTarget, settingsFloat) : default; }
                    case TweenType.LocalPositionZ: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.LocalPositionZ(tweenTarget, settingsFloat) : default; }
                    case TweenType.Scale: { return GetUnityTarget<Transform>(out var tweenTarget, ref err, i) ? Tween.Scale(tweenTarget, settingsVector3) : default; }
                    default:
                        err = $"'{tweenType}' tween type is only available in PrimeTween PRO: {Constants.proVersionUrl}";
                        return default;
                }
            }
        }
    }
}
