/*
// ReSharper disable UnusedMemberInSuper.Global
using System;
using JetBrains.Annotations;

namespace PrimeTween {
    // ReSharper disable once TypeParameterCanBeVariant
    internal interface ITween<TResult> {
        bool isAlive { get; }
        void Stop();
        void Complete();
        void SetRemainingCycles(int cycles);
        void SetRemainingCycles(bool stopAtEndValue);
        
        int cyclesDone { get; }
        int cyclesTotal { get; }
        bool isPaused { get; set; }
        float timeScale { get; set; }
        float duration { get; }
        float durationTotal { get; }
        float elapsedTime { get; set; }
        float elapsedTimeTotal { get; set; }
        float progress { get; set; }
        float progressTotal { get; set; }

        public System.Collections.IEnumerator ToYieldInstruction();
        #pragma warning disable CS0618 // Type or member is obsolete
        public Tween.TweenAwaiter GetAwaiter();
        #pragma warning restore CS0618 // Type or member is obsolete

        TResult OnComplete([NotNull] Action onComplete, bool? warnIfTargetDestroyed = null);
        TResult OnComplete<T>([NotNull] T target, [NotNull] Action<T> onComplete, bool? warnIfTargetDestroyed = null) where T : class;
        Sequence Group(Tween tween);
        Sequence Chain(Tween tween);
        Sequence Group(Sequence sequence);
        Sequence Chain(Sequence sequence);
        TResult OnFinally<T>([CanBeNull] T target, Action<T> onFinally) where T : class;
        TResult OnUpdate<T>(T target, Action<T, TResult> onUpdate) where T : class; // Sequence invokes OnUpdate() AFTER all its children are updated

        TResult ResetOnCompletion();
        TResult SetCancellationToken(CancellationToken token);
        TResult SetClock([NotNull] Tween.Clock clock);


        // Tween only:
        float interpolationFactor { get; }


        // Sequence only:
        Sequence GroupCallback([NotNull] Action callback, bool? warnIfTargetDestroyed = null);
        Sequence GroupCallback<T>([NotNull] T target, [NotNull] Action<T> callback, bool? warnIfTargetDestroyed = null);

        Sequence ChainCallback([NotNull] Action callback, bool? warnIfTargetDestroyed = null)
        Sequence ChainCallback<T>([NotNull] T target, [NotNull] Action<T> callback, bool? warnIfTargetDestroyed = null);

        Sequence Insert(float atTime, Tween tween);
        Sequence Insert(float atTime, Sequence sequence);

        Sequence InsertCallback(float atTime, Action callback, bool? warnIfTargetDestroyed = null)
        Sequence InsertCallback<T>(float atTime, [NotNull] T target, Action<T> callback, bool? warnIfTargetDestroyed = null);
    }
}
*/
